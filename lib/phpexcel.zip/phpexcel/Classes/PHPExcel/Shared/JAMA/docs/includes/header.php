<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>JAMA v1.0.1</title>
		<meta name="description" content="JAMA v1.0.1 - Port of the proposed standard Java Matrix Library to PHP" />
		<meta name="robots" content="index, follow" />
		<meta name="keywords" content="php, matrix, matrix library, cholesky decomposition, eigenvalue decomposition, eigenvector, lu decomposition, qr decomposition, singular value decomposition" />
		<link rel="stylesheet" type="text/css" href="style.css" />
	</head>
	<body>
